### Hexlet tests and linter status:
[![Actions Status](https://github.com/DanilaMiller/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DanilaMiller/python-project-49/actions)
<a 
href="https://codeclimate.com/github/DanilaMiller/python-project-49/maintainability"><img 
src="https://api.codeclimate.com/v1/badges/9efafe0fd8034f33a9ae/maintainability" 
/></a>

https://asciinema.org/a/532193
https://asciinema.org/a/532483
https://asciinema.org/a/533945
https://asciinema.org/a/534231
https://asciinema.org/a/534807
