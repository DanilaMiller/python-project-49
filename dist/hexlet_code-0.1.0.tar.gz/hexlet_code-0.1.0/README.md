### Hexlet tests and linter status:
[![Actions Status](https://github.com/DanilaMiller/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DanilaMiller/python-project-49/actions)

https://asciinema.org/a/532193
https://asciinema.org/a/532483
https://asciinema.org/a/533945
